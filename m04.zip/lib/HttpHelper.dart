import 'dart:io';
import 'package:http/http.dart'as http;

class HttpHelper{
  final String _urlKey = "?api_key=3b47aaf2601253455fee120b0d19c199";
  final String _urlBase = "https://api.themoviedb.org/3/movie";

  Future<String> getMovie() async {
    var url = Uri.parse(_urlBase + "/now_playing" + _urlKey);
    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      String responseBody = result.body;
      return responseBody;
    }
    return result.statusCode.toString();
  }
}
