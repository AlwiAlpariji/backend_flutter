import 'package:flutter/material.dart';
import 'package:m04/HttpHelper.dart';

class Screen1 extends StatefulWidget {
  const Screen1({Key? key}): super(key: key);

  @override
  State<Screen1> createState() => _Screen1State();
}

class _Screen1State extends State<Screen1> {
  late String result;
  late HttpHelper helper;

  @override
  void initState() {
    super.initState();
    helper = HttpHelper();
    result = "";

    helper.getMovie().then((value) {
      setState(() {
        result = value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My movie')),
      body: SingleChildScrollView(
        child: Text("$result"),
      ),
    );
  }
}
